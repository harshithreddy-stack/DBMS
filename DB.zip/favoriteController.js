/**
 * Favorite Controller
 */

const favoriteService = require('../services/favoriteService');
const { successResponse, errorResponse } = require('../utils/responseHelper');

async function getFavorites(req, res, next) {
  try {
    const favorites = await favoriteService.getUserFavorites(req.user.id);
    return successResponse(res, favorites, 'Favorites retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function addFavorite(req, res, next) {
  try {
    const { route_id } = req.body;
    if (!route_id) {
      return errorResponse(res, 'route_id is required', 400);
    }
    const result = await favoriteService.addFavorite(req.user.id, route_id);
    return successResponse(res, result, 'Route added to favorites', 201);
  } catch (error) {
    next(error);
  }
}

async function deleteFavorite(req, res, next) {
  try {
    const { id } = req.params;
    const result = await favoriteService.removeFavorite(req.user.id, id);
    return successResponse(res, result, 'Favorite removed successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getFavorites,
  addFavorite,
  deleteFavorite
};
