/**
 * Dashboard Controller
 */

const dashboardService = require('../services/dashboardService');
const { successResponse } = require('../utils/responseHelper');

async function getStats(req, res, next) {
  try {
    const data = await dashboardService.getDashboardStats();
    return successResponse(res, data, 'Dashboard statistics retrieved successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getStats
};
