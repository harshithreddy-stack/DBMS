/**
 * Bus Controller
 */

const busService = require('../services/busService');
const { successResponse, errorResponse } = require('../utils/responseHelper');
const { isNonEmptyString, isPositiveNumber } = require('../utils/validators');

async function getBuses(req, res, next) {
  try {
    const { status, bus_type, search } = req.query;
    const buses = await busService.getAllBuses({ status, bus_type, search });
    return successResponse(res, buses, 'Buses retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function getBus(req, res, next) {
  try {
    const { id } = req.params;
    const bus = await busService.getBusById(id);
    return successResponse(res, bus, 'Bus details retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function createBus(req, res, next) {
  try {
    const { bus_number, bus_type, capacity, status } = req.body;

    if (!isNonEmptyString(bus_number)) {
      return errorResponse(res, 'Bus registration number is required', 400);
    }
    if (!isNonEmptyString(bus_type)) {
      return errorResponse(res, 'Bus type is required (e.g. AC Electric, Super Luxury)', 400);
    }
    if (capacity !== undefined && !isPositiveNumber(capacity)) {
      return errorResponse(res, 'Capacity must be a positive integer', 400);
    }

    const bus = await busService.createBus({ bus_number, bus_type, capacity, status });
    return successResponse(res, bus, 'Bus created successfully', 201);
  } catch (error) {
    next(error);
  }
}

async function updateBus(req, res, next) {
  try {
    const { id } = req.params;
    const { bus_number, bus_type, capacity, status } = req.body;

    if (capacity !== undefined && !isPositiveNumber(capacity)) {
      return errorResponse(res, 'Capacity must be a positive integer', 400);
    }

    const bus = await busService.updateBus(id, { bus_number, bus_type, capacity, status });
    return successResponse(res, bus, 'Bus updated successfully');
  } catch (error) {
    next(error);
  }
}

async function deleteBus(req, res, next) {
  try {
    const { id } = req.params;
    const result = await busService.deleteBus(id);
    return successResponse(res, result, 'Bus deleted successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getBuses,
  getBus,
  createBus,
  updateBus,
  deleteBus
};
