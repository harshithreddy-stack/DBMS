# Smart Public Transport - PowerShell Launcher
$ErrorActionPreference = "Continue"

Write-Host "====================================================================" -ForegroundColor Cyan
Write-Host "       SMART PUBLIC TRANSPORT - ONE-CLICK POWERSHELL LAUNCHER       " -ForegroundColor Yellow
Write-Host "====================================================================" -ForegroundColor Cyan
Write-Host ""

$root = $PSScriptRoot
$backendDir = Join-Path $root "smart-public-transport\backend"
$frontendDir = Join-Path $root "smart-public-transport\frontend"

if (-not (Test-Path $backendDir)) {
    $backendDir = Join-Path $root "backend"
    $frontendDir = Join-Path $root "frontend"
}

# 1. Check .env
$envFile = Join-Path $backendDir ".env"
$envExample = Join-Path $backendDir ".env.example"
if (-not (Test-Path $envFile)) {
    Copy-Item $envExample $envFile
    Write-Host "[OK] Created .env file." -ForegroundColor Green
}

# 2. Check Database initialization
Write-Host "[INFO] Checking MySQL database..." -ForegroundColor White
Push-Location $backendDir
$dbTest = Start-Process -FilePath "node" -ArgumentList "scripts/initDb.js" -NoNewWindow -Wait -PassThru
if ($dbTest.ExitCode -ne 0) {
    Write-Host ""
    $pass = Read-Host ">> Enter your local MySQL root password (or press Enter if blank)"
    $dbInit = Start-Process -FilePath "node" -ArgumentList "scripts/initDb.js `"$pass`"" -NoNewWindow -Wait -PassThru
    if ($dbInit.ExitCode -eq 0) {
        (Get-Content $envFile) -replace '^DB_PASSWORD=.*', "DB_PASSWORD=$pass" | Set-Content $envFile
        Write-Host "[OK] Database seeded and .env updated successfully!" -ForegroundColor Green
    }
}
Pop-Location

# 3. Start Backend
Write-Host "[INFO] Starting Backend on http://localhost:5000..." -ForegroundColor Cyan
Start-Process -FilePath "cmd.exe" -ArgumentList "/c cd /d `"$backendDir`" && npm run dev"

# 4. Start Frontend
Write-Host "[INFO] Starting Frontend on http://localhost:5173..." -ForegroundColor Cyan
Start-Process -FilePath "cmd.exe" -ArgumentList "/c cd /d `"$frontendDir`" && npm run dev"

# 5. Open browser
Start-Sleep -Seconds 3
Start-Process "http://localhost:5173"

Write-Host ""
Write-Host "[SUCCESS] Smart Public Transport is now running in your browser!" -ForegroundColor Green
Write-Host "Close the opened console windows when you wish to terminate the servers." -ForegroundColor Gray
