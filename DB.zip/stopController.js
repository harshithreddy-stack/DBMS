/**
 * Stop Controller
 */

const stopService = require('../services/stopService');
const { successResponse, errorResponse } = require('../utils/responseHelper');
const { isNonEmptyString } = require('../utils/validators');

async function getStops(req, res, next) {
  try {
    const { search } = req.query;
    const stops = await stopService.getAllStops({ search });
    return successResponse(res, stops, 'Stops retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function getStop(req, res, next) {
  try {
    const { id } = req.params;
    const stop = await stopService.getStopById(id);
    return successResponse(res, stop, 'Stop details retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function createStop(req, res, next) {
  try {
    const { stop_name, location } = req.body;

    if (!isNonEmptyString(stop_name)) {
      return errorResponse(res, 'Stop name is required', 400);
    }
    if (!isNonEmptyString(location)) {
      return errorResponse(res, 'Location / landmark description is required', 400);
    }

    const stop = await stopService.createStop({ stop_name, location });
    return successResponse(res, stop, 'Stop created successfully', 201);
  } catch (error) {
    next(error);
  }
}

async function updateStop(req, res, next) {
  try {
    const { id } = req.params;
    const { stop_name, location } = req.body;

    const stop = await stopService.updateStop(id, { stop_name, location });
    return successResponse(res, stop, 'Stop updated successfully');
  } catch (error) {
    next(error);
  }
}

async function deleteStop(req, res, next) {
  try {
    const { id } = req.params;
    const result = await stopService.deleteStop(id);
    return successResponse(res, result, 'Stop deleted successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getStops,
  getStop,
  createStop,
  updateStop,
  deleteStop
};
