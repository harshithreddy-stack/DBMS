/**
 * Authentication and Authorization Middleware
 */

const { verifyTokenString } = require('../utils/jwt');
const { errorResponse } = require('../utils/responseHelper');
const { pool } = require('../config/db');

/**
 * Verify JWT token from Authorization header (Bearer <token>)
 */
async function verifyToken(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return errorResponse(res, 'Authentication token missing or invalid', 401);
    }

    const token = authHeader.split(' ')[1];
    let decoded;
    try {
      decoded = verifyTokenString(token);
    } catch (err) {
      return errorResponse(res, 'Session expired or token invalid. Please log in again.', 401);
    }

    // Attach decoded user info to request
    req.user = decoded;
    next();
  } catch (error) {
    return errorResponse(res, 'Internal authentication error', 500);
  }
}

/**
 * Enforce Admin Role
 */
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return errorResponse(res, 'Access denied. Administrator privileges required.', 403);
  }
  next();
}

/**
 * Optional authentication: attaches user if token present, but doesn't block if missing
 */
function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      req.user = verifyTokenString(token);
    } catch (err) {
      // ignore invalid token for optional auth
    }
  }
  next();
}

module.exports = {
  verifyToken,
  requireAdmin,
  optionalAuth
};
