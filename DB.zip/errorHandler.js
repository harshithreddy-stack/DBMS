/**
 * Centralized Error Handling Middleware
 */

const { errorResponse } = require('../utils/responseHelper');

function errorHandler(err, req, res, next) {
  console.error('[SERVER ERROR]:', err);

  // MySQL Duplicate Key Error
  if (err.code === 'ER_DUP_ENTRY') {
    let msg = 'Duplicate entry error: A record with this unique identifier already exists.';
    if (err.message.includes('users.email')) {
      msg = 'An account with this email address already exists.';
    } else if (err.message.includes('buses.bus_number')) {
      msg = 'A bus with this registration number already exists.';
    } else if (err.message.includes('routes.route_number')) {
      msg = 'A route with this route number already exists.';
    }
    return errorResponse(res, msg, 409);
  }

  // MySQL Foreign Key Constraint Error
  if (err.code === 'ER_NO_REFERENCED_ROW_2' || err.code === 'ER_ROW_IS_REFERENCED_2') {
    return errorResponse(
      res,
      'Relational constraint violation: Referenced record does not exist or is currently in use.',
      400
    );
  }

  // MySQL Syntax or Column Error
  if (err.code === 'ER_BAD_FIELD_ERROR') {
    return errorResponse(res, 'Database query error: Invalid field reference.', 500);
  }

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';

  return errorResponse(res, message, statusCode);
}

module.exports = errorHandler;
