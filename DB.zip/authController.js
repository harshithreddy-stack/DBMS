/**
 * Authentication Controller
 */

const authService = require('../services/authService');
const { successResponse, errorResponse } = require('../utils/responseHelper');
const { isValidEmail, isValidPhone, isNonEmptyString } = require('../utils/validators');

async function register(req, res, next) {
  try {
    const { name, email, phone, password, confirmPassword } = req.body;

    if (!isNonEmptyString(name)) {
      return errorResponse(res, 'Full name is required', 400);
    }
    if (!isValidEmail(email)) {
      return errorResponse(res, 'A valid email address is required', 400);
    }
    if (!isValidPhone(phone)) {
      return errorResponse(res, 'A valid phone number is required (7-15 digits)', 400);
    }
    if (!password || password.length < 6) {
      return errorResponse(res, 'Password must be at least 6 characters long', 400);
    }
    if (confirmPassword !== undefined && password !== confirmPassword) {
      return errorResponse(res, 'Passwords do not match', 400);
    }

    const data = await authService.registerUser({ name, email, phone, password });
    return successResponse(res, data, 'Registration successful', 201);
  } catch (error) {
    next(error);
  }
}

async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    if (!isValidEmail(email) || !password) {
      return errorResponse(res, 'Email and password are required', 400);
    }

    const data = await authService.loginUser({ email, password });
    return successResponse(res, data, 'Login successful');
  } catch (error) {
    next(error);
  }
}

async function getProfile(req, res, next) {
  try {
    const user = await authService.getUserProfile(req.user.id);
    return successResponse(res, user, 'Profile retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function updateProfile(req, res, next) {
  try {
    const { name, phone, password } = req.body;
    const user = await authService.updateUserProfile(req.user.id, { name, phone, password });
    return successResponse(res, user, 'Profile updated successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  register,
  login,
  getProfile,
  updateProfile
};
