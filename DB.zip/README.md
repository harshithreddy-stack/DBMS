# Smart Public Transport Mobile App
A complete full-stack college DBMS project for B.Tech CS/IT.

The project is organized in the `smart-public-transport/` directory:

```text
smart-public-transport/
├── frontend/     # React 18 + Vite SPA
├── backend/      # Node.js + Express + MySQL API
├── database/     # schema.sql, seed.sql, ER_DIAGRAM.md
└── README.md     # Full Documentation & Viva Q&A Guide
```

### Quick Run Instructions

#### 1. Database Setup
```bash
cd smart-public-transport/backend
# Update DB_PASSWORD in .env
npm run db:init
```

#### 2. Start Backend
```bash
cd smart-public-transport/backend
npm install
npm run dev
```

#### 3. Start Frontend
```bash
cd smart-public-transport/frontend
npm install
npm run dev
```

Full details, ER diagrams, sample accounts, and viva explanations are inside [smart-public-transport/README.md](file:///c:/Users/harsh/OneDrive/Desktop/DBMS/smart-public-transport/README.md) and [smart-public-transport/database/ER_DIAGRAM.md](file:///c:/Users/harsh/OneDrive/Desktop/DBMS/smart-public-transport/database/ER_DIAGRAM.md).
