-- ====================================================================
-- SMART PUBLIC TRANSPORT MOBILE APP - DATABASE SCHEMA
-- DBMS: MySQL 8.0+
-- Database Name: smart_public_transport
-- Description: Normalized relational schema (approx. 3NF) for
--              public transit management, bus scheduling, bookings,
--              route navigation, and administrative analytics.
-- ====================================================================

-- 1. Create Database if not exists
CREATE DATABASE IF NOT EXISTS smart_public_transport
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE smart_public_transport;

-- Disable foreign key checks during creation/drop for clean idempotent execution
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS favorites;
DROP TABLE IF EXISTS schedules;
DROP TABLE IF EXISTS route_stops;
DROP TABLE IF EXISTS stops;
DROP TABLE IF EXISTS routes;
DROP TABLE IF EXISTS buses;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- ====================================================================
-- Table 1: users
-- Represents passengers and system administrators.
-- ====================================================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Table 2: buses
-- Physical transit vehicles in the fleet.
-- ====================================================================
CREATE TABLE buses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bus_number VARCHAR(30) NOT NULL UNIQUE,
    bus_type VARCHAR(50) NOT NULL COMMENT 'e.g. AC Electric, Super Luxury, Metro Express, City Ordinary',
    capacity INT NOT NULL DEFAULT 40,
    status ENUM('Active', 'Maintenance', 'Out of Service') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_buses_number (bus_number),
    INDEX idx_buses_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Table 3: routes
-- Defined transportation corridors between source and destination.
-- ====================================================================
CREATE TABLE routes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    route_number VARCHAR(30) NOT NULL UNIQUE,
    route_name VARCHAR(150) NOT NULL,
    source VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    distance DECIMAL(6,2) NOT NULL COMMENT 'Distance in Kilometers',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_routes_number (route_number),
    INDEX idx_routes_source_dest (source, destination)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Table 4: stops
-- Physical transit stops / bus shelters across the metropolitan area.
-- ====================================================================
CREATE TABLE stops (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stop_name VARCHAR(100) NOT NULL,
    location VARCHAR(150) NOT NULL COMMENT 'Area, Landmark, or Coordinates description',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stops_name (stop_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Table 5: route_stops (Junction Table)
-- Ordered sequence of stops along a specific route with timings.
-- ====================================================================
CREATE TABLE route_stops (
    id INT AUTO_INCREMENT PRIMARY KEY,
    route_id INT NOT NULL,
    stop_id INT NOT NULL,
    stop_order INT NOT NULL,
    arrival_time TIME NULL,
    departure_time TIME NULL,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (stop_id) REFERENCES stops(id) ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE KEY uk_route_stop_order (route_id, stop_order),
    UNIQUE KEY uk_route_stop (route_id, stop_id),
    INDEX idx_rs_route (route_id),
    INDEX idx_rs_stop (stop_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Table 6: schedules
-- Assignment of buses to routes with departure, arrival, and fare.
-- ====================================================================
CREATE TABLE schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bus_id INT NOT NULL,
    route_id INT NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    fare DECIMAL(8,2) NOT NULL,
    days VARCHAR(100) DEFAULT 'Daily' COMMENT 'e.g. Daily, Mon-Fri, Weekends',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bus_id) REFERENCES buses(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_schedules_bus (bus_id),
    INDEX idx_schedules_route (route_id),
    INDEX idx_schedules_times (departure_time, arrival_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Table 7: favorites
-- Passenger bookmarked favorite routes for instant access.
-- ====================================================================
CREATE TABLE favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    route_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE KEY uk_user_route_fav (user_id, route_id),
    INDEX idx_favorites_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Table 8: bookings
-- Ticket reservations made by passengers for scheduled bus runs.
-- Handled inside ACID transactions in the application.
-- ====================================================================
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    bus_id INT NOT NULL,
    route_id INT NOT NULL,
    booking_date DATE NOT NULL,
    fare DECIMAL(8,2) NOT NULL,
    status ENUM('Confirmed', 'Pending', 'Cancelled') DEFAULT 'Confirmed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (bus_id) REFERENCES buses(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_bookings_user (user_id),
    INDEX idx_bookings_date (booking_date),
    INDEX idx_bookings_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Table 9: notifications
-- System and transit alerts sent to users.
-- ====================================================================
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message VARCHAR(255) NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_notifications_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
