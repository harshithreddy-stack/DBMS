-- ====================================================================
-- SMART PUBLIC TRANSPORT MOBILE APP - DBMS DEMO QUERIES
-- For B.Tech CS/IT Project Viva & Practical Demonstration
-- Covers: Single & Multiple-Table JOINs, Aggregates, Grouping,
--         Subqueries, Index Optimization, and ACID Transactions.
-- ====================================================================

USE smart_public_transport;

-- --------------------------------------------------------------------
-- 1. BASIC SELECT & FILTERING (WITH INDEX CHECK)
-- --------------------------------------------------------------------
-- Find all active buses of type 'AC Electric'
SELECT id, bus_number, bus_type, capacity, status
FROM buses
WHERE bus_type = 'AC Electric' AND status = 'Active';

-- Check index usage using EXPLAIN
EXPLAIN SELECT * FROM users WHERE email = 'rahul@gmail.com';


-- --------------------------------------------------------------------
-- 2. INNER JOIN: Bus Schedules with Route & Bus Details (3-Table JOIN)
-- --------------------------------------------------------------------
SELECT 
    s.id AS schedule_id,
    b.bus_number,
    b.bus_type,
    r.route_number,
    r.route_name,
    r.source,
    r.destination,
    s.departure_time,
    s.arrival_time,
    s.fare,
    s.days
FROM schedules s
INNER JOIN buses b ON s.bus_id = b.id
INNER JOIN routes r ON s.route_id = r.id
ORDER BY s.departure_time ASC;


-- --------------------------------------------------------------------
-- 3. MULTIPLE-TABLE JOIN: Ordered Stops Along a Route
-- --------------------------------------------------------------------
SELECT 
    r.route_number,
    r.route_name,
    rs.stop_order,
    st.stop_name,
    st.location,
    rs.arrival_time,
    rs.departure_time
FROM route_stops rs
INNER JOIN routes r ON rs.route_id = r.id
INNER JOIN stops st ON rs.stop_id = st.id
WHERE r.route_number = '218'
ORDER BY rs.stop_order ASC;


-- --------------------------------------------------------------------
-- 4. SEARCH QUERY WITH JOIN: Find Direct or Connecting Transit
-- Matches direct routes between source and destination (or intermediate stops)
-- --------------------------------------------------------------------
SELECT 
    r.id AS route_id,
    r.route_number,
    r.route_name,
    r.source,
    r.destination,
    b.bus_number,
    b.bus_type,
    b.capacity,
    s.id AS schedule_id,
    s.departure_time,
    s.arrival_time,
    s.fare,
    s.days
FROM routes r
INNER JOIN schedules s ON r.id = s.route_id
INNER JOIN buses b ON s.bus_id = b.id
WHERE b.status = 'Active'
  AND (
      (LOWER(r.source) LIKE LOWER('%Secunderabad%') AND LOWER(r.destination) LIKE LOWER('%Mehdipatnam%'))
      OR r.id IN (
          -- Subquery to check if source stop appears before destination stop in route_stops
          SELECT rs1.route_id
          FROM route_stops rs1
          INNER JOIN stops s1 ON rs1.stop_id = s1.id
          INNER JOIN route_stops rs2 ON rs1.route_id = rs2.route_id
          INNER JOIN stops s2 ON rs2.stop_id = s2.id
          WHERE LOWER(s1.stop_name) LIKE LOWER('%Secunderabad%')
            AND LOWER(s2.stop_name) LIKE LOWER('%Mehdipatnam%')
            AND rs1.stop_order < rs2.stop_order
      )
  )
ORDER BY s.departure_time ASC;


-- --------------------------------------------------------------------
-- 5. LEFT JOIN: All Routes with Count of Stops & Assigned Buses
-- --------------------------------------------------------------------
SELECT 
    r.id AS route_id,
    r.route_number,
    r.route_name,
    r.distance,
    COUNT(DISTINCT rs.stop_id) AS total_stops,
    COUNT(DISTINCT s.bus_id) AS total_assigned_buses
FROM routes r
LEFT JOIN route_stops rs ON r.id = rs.route_id
LEFT JOIN schedules s ON r.id = s.route_id
GROUP BY r.id, r.route_number, r.route_name, r.distance
ORDER BY total_assigned_buses DESC;


-- --------------------------------------------------------------------
-- 6. USER FAVORITES JOIN: Showing Route Details for a Given User
-- --------------------------------------------------------------------
SELECT 
    f.id AS favorite_id,
    u.id AS user_id,
    u.name AS user_name,
    r.route_number,
    r.route_name,
    r.source,
    r.destination,
    r.distance,
    f.created_at AS bookmarked_on
FROM favorites f
INNER JOIN users u ON f.user_id = u.id
INNER JOIN routes r ON f.route_id = r.id
WHERE u.id = 2
ORDER BY f.created_at DESC;


-- --------------------------------------------------------------------
-- 7. AGGREGATE FUNCTIONS: Executive Dashboard Metrics
-- Demonstrates COUNT(), SUM(), AVG(), MIN(), MAX()
-- --------------------------------------------------------------------
SELECT 
    (SELECT COUNT(*) FROM users WHERE role = 'user') AS total_passengers,
    (SELECT COUNT(*) FROM buses) AS total_buses,
    (SELECT COUNT(*) FROM buses WHERE status = 'Active') AS active_buses,
    (SELECT COUNT(*) FROM routes) AS total_routes,
    (SELECT COUNT(*) FROM stops) AS total_stops,
    (SELECT COUNT(*) FROM schedules) AS total_schedules,
    (SELECT COUNT(*) FROM bookings WHERE status = 'Confirmed') AS total_confirmed_bookings,
    (SELECT IFNULL(SUM(fare), 0) FROM bookings WHERE status = 'Confirmed') AS total_revenue,
    (SELECT IFNULL(ROUND(AVG(fare), 2), 0) FROM schedules) AS average_fare,
    (SELECT IFNULL(MIN(fare), 0) FROM schedules) AS minimum_fare,
    (SELECT IFNULL(MAX(fare), 0) FROM schedules) AS maximum_fare;


-- --------------------------------------------------------------------
-- 8. GROUP BY & AGGREGATE: Bus Count by Bus Type
-- --------------------------------------------------------------------
SELECT 
    bus_type,
    COUNT(*) AS total_count,
    ROUND(AVG(capacity), 1) AS average_capacity
FROM buses
GROUP BY bus_type
ORDER BY total_count DESC;


-- --------------------------------------------------------------------
-- 9. SUBQUERY & CORRELATED SUBQUERY: Top Booked Routes
-- --------------------------------------------------------------------
SELECT 
    r.route_number,
    r.route_name,
    (SELECT COUNT(*) FROM bookings b WHERE b.route_id = r.id) AS booking_count
FROM routes r
ORDER BY booking_count DESC
LIMIT 5;


-- --------------------------------------------------------------------
-- 10. DATABASE TRANSACTION (ACID Demonstration)
-- Simulates booking creation with ticket generation & notification
-- --------------------------------------------------------------------
START TRANSACTION;

-- Step 1: Insert new booking record
INSERT INTO bookings (user_id, bus_id, route_id, booking_date, fare, status)
VALUES (2, 1, 1, CURDATE(), 50.00, 'Confirmed');

-- Step 2: Get generated booking ID
SET @new_booking_id = LAST_INSERT_ID();

-- Step 3: Automatically generate user notification
INSERT INTO notifications (user_id, message, is_read)
VALUES (2, CONCAT('Your booking #', @new_booking_id, ' for Route 218 is successfully confirmed.'), FALSE);

-- Step 4: Commit the atomic transaction
COMMIT;

-- (If any step failed, ROLLBACK is executed)
-- ROLLBACK;
