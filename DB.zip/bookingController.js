/**
 * Booking Controller
 */

const bookingService = require('../services/bookingService');
const { successResponse, errorResponse } = require('../utils/responseHelper');
const { isPositiveNumber } = require('../utils/validators');

async function createBooking(req, res, next) {
  try {
    const { bus_id, route_id, booking_date, fare } = req.body;

    if (!bus_id || !route_id) {
      return errorResponse(res, 'bus_id and route_id are required', 400);
    }
    if (!booking_date) {
      return errorResponse(res, 'booking_date is required (YYYY-MM-DD)', 400);
    }
    if (!isPositiveNumber(fare)) {
      return errorResponse(res, 'fare must be a positive number', 400);
    }

    const booking = await bookingService.createBooking({
      userId: req.user.id,
      bus_id,
      route_id,
      booking_date,
      fare
    });

    return successResponse(res, booking, 'Booking confirmed successfully (Transaction committed)', 201);
  } catch (error) {
    next(error);
  }
}

async function getMyBookings(req, res, next) {
  try {
    const bookings = await bookingService.getUserBookings(req.user.id);
    return successResponse(res, bookings, 'Bookings retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function getAllBookings(req, res, next) {
  try {
    const bookings = await bookingService.getAllBookings();
    return successResponse(res, bookings, 'All bookings retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function getBooking(req, res, next) {
  try {
    const { id } = req.params;
    const booking = await bookingService.getBookingById(id, req.user.id, req.user.role);
    return successResponse(res, booking, 'Booking details retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function cancelBooking(req, res, next) {
  try {
    const { id } = req.params;
    const result = await bookingService.cancelBooking(id, req.user.id, req.user.role);
    return successResponse(res, result, 'Booking cancelled successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  createBooking,
  getMyBookings,
  getAllBookings,
  getBooking,
  cancelBooking
};
