# Database Design & Entity Relationship (ER) Documentation
**Project Title**: Smart Public Transport Mobile App  
**DBMS**: MySQL 8.0+  
**Database Name**: `smart_public_transport`

---

## 1. Conceptual ER Diagram (Mermaid)

```mermaid
erDiagram
    USERS ||--o{ FAVORITES : "bookmarks"
    USERS ||--o{ BOOKINGS : "reserves"
    USERS ||--o{ NOTIFICATIONS : "receives"
    
    ROUTES ||--o{ FAVORITES : "is bookmarked in"
    ROUTES ||--o{ ROUTE_STOPS : "consists of"
    ROUTES ||--o{ SCHEDULES : "scheduled on"
    ROUTES ||--o{ BOOKINGS : "associated with"

    STOPS ||--o{ ROUTE_STOPS : "located at"

    BUSES ||--o{ SCHEDULES : "assigned to"
    BUSES ||--o{ BOOKINGS : "allocated for"

    USERS {
        int id PK
        string name
        string email UK
        string phone
        string password
        enum role
        timestamp created_at
    }

    BUSES {
        int id PK
        string bus_number UK
        string bus_type
        int capacity
        enum status
        timestamp created_at
    }

    ROUTES {
        int id PK
        string route_number UK
        string route_name
        string source
        string destination
        decimal distance
        timestamp created_at
    }

    STOPS {
        int id PK
        string stop_name
        string location
        timestamp created_at
    }

    ROUTE_STOPS {
        int id PK
        int route_id FK
        int stop_id FK
        int stop_order
        time arrival_time
        time departure_time
    }

    SCHEDULES {
        int id PK
        int bus_id FK
        int route_id FK
        time departure_time
        time arrival_time
        decimal fare
        string days
        timestamp created_at
    }

    FAVORITES {
        int id PK
        int user_id FK
        int route_id FK
        timestamp created_at
    }

    BOOKINGS {
        int id PK
        int user_id FK
        int bus_id FK
        int route_id FK
        date booking_date
        decimal fare
        enum status
        timestamp created_at
    }

    NOTIFICATIONS {
        int id PK
        int user_id FK
        string message
        boolean is_read
        timestamp created_at
    }
```

---

## 2. Entities & Attribute Specifications

### 1. `users`
- **Purpose**: Stores passenger credentials, contact information, and role-based permissions.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Unique identifier for each user.
  - `name` (VARCHAR(100), NOT NULL): Full name of the user.
  - `email` (VARCHAR(120), NOT NULL, UNIQUE): Unique email address used for system login.
  - `phone` (VARCHAR(20), NOT NULL): Contact mobile number.
  - `password` (VARCHAR(255), NOT NULL): Salted bcrypt hash of user password.
  - `role` (ENUM('user', 'admin'), DEFAULT 'user'): Security role for access control.
  - `created_at` (TIMESTAMP, DEFAULT CURRENT_TIMESTAMP): Account registration timestamp.

### 2. `buses`
- **Purpose**: Tracks fleet inventory, vehicle capacity, operational readiness, and classification.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Unique identifier for the bus vehicle.
  - `bus_number` (VARCHAR(30), NOT NULL, UNIQUE): Vehicle registration number (e.g., TS09UB1001).
  - `bus_type` (VARCHAR(50), NOT NULL): Vehicle category (AC Electric, Super Luxury, Metro Express, etc.).
  - `capacity` (INT, NOT NULL, DEFAULT 40): Total passenger seating capacity.
  - `status` (ENUM('Active', 'Maintenance', 'Out of Service'), DEFAULT 'Active'): Current fleet operational state.

### 3. `routes`
- **Purpose**: Defines public transit lines connecting distinct geographic terminals.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Unique identifier for the transit route.
  - `route_number` (VARCHAR(30), NOT NULL, UNIQUE): Designated public route code (e.g., 218, 10H, 5K).
  - `route_name` (VARCHAR(150), NOT NULL): Descriptive path summary.
  - `source` (VARCHAR(100), NOT NULL): Primary departure terminus.
  - `destination` (VARCHAR(100), NOT NULL): Primary terminating station.
  - `distance` (DECIMAL(6,2), NOT NULL): Total corridor distance in kilometers.

### 4. `stops`
- **Purpose**: Catalogs physical boarding stations and shelter locations across the region.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Unique identifier for the stop.
  - `stop_name` (VARCHAR(100), NOT NULL): Official name of the station or stop.
  - `location` (VARCHAR(150), NOT NULL): Street, junction, or geographic landmark.

### 5. `route_stops` (Junction Entity: Many-to-Many between `routes` and `stops`)
- **Purpose**: Models the ordered progression of stations visited along any given route.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Junction surrogate key.
  - `route_id` (INT, FK -> routes.id): Foreign key reference to the parent route.
  - `stop_id` (INT, FK -> stops.id): Foreign key reference to the stop.
  - `stop_order` (INT, NOT NULL): 1-indexed sequential sequence along the transit path.
  - `arrival_time` (TIME, NULL): Estimated time of arrival at this stop.
  - `departure_time` (TIME, NULL): Estimated departure time from this stop.
- **Constraints**:
  - UNIQUE(`route_id`, `stop_order`) ensures two stops cannot occupy the same sequence position on the same route.
  - UNIQUE(`route_id`, `stop_id`) prevents duplicate stop attachments on the same route.

### 6. `schedules`
- **Purpose**: Maps operational vehicle assignments to route departure/arrival slots with fares.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Unique schedule identifier.
  - `bus_id` (INT, FK -> buses.id): Assigned transit bus.
  - `route_id` (INT, FK -> routes.id): Assigned transit route.
  - `departure_time` (TIME, NOT NULL): Scheduled run departure time.
  - `arrival_time` (TIME, NOT NULL): Scheduled destination arrival time.
  - `fare` (DECIMAL(8,2), NOT NULL): Base ticket price for this run.
  - `days` (VARCHAR(100), DEFAULT 'Daily'): Operational service calendar (e.g., Daily, Mon-Sat).

### 7. `favorites`
- **Purpose**: Allows passengers to bookmark their frequent commute routes for 1-click access.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Unique favorite identifier.
  - `user_id` (INT, FK -> users.id): The bookmarking user.
  - `route_id` (INT, FK -> routes.id): The bookmarked route.
  - `created_at` (TIMESTAMP): Time of bookmark creation.
- **Constraints**: UNIQUE(`user_id`, `route_id`) prevents duplicate favorites.

### 8. `bookings`
- **Purpose**: Records ticket purchases and seat reservations made by passengers.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Ticket/Booking ID.
  - `user_id` (INT, FK -> users.id): Passenger making the reservation.
  - `bus_id` (INT, FK -> buses.id): Booked vehicle.
  - `route_id` (INT, FK -> routes.id): Booked route.
  - `booking_date` (DATE, NOT NULL): Date of travel.
  - `fare` (DECIMAL(8,2), NOT NULL): Fare charged at the time of purchase.
  - `status` (ENUM('Confirmed', 'Pending', 'Cancelled'), DEFAULT 'Confirmed'): Current reservation lifecycle state.

### 9. `notifications`
- **Purpose**: In-app message log for updates, confirmations, and alerts.
- **Attributes**:
  - `id` (INT, PK, Auto Increment): Notification ID.
  - `user_id` (INT, FK -> users.id): Recipient user.
  - `message` (VARCHAR(255), NOT NULL): Alert message body.
  - `is_read` (BOOLEAN, DEFAULT FALSE): Read/unread flag.
  - `created_at` (TIMESTAMP): Notification dispatch timestamp.

---

## 3. Relationships & Cardinality

| Parent Entity | Child Entity | Relationship Type | Cardinality | Foreign Key Constraint |
| :--- | :--- | :--- | :--- | :--- |
| `users` | `favorites` | One-to-Many | 1 : N | `favorites.user_id` -> `users.id` (ON DELETE CASCADE) |
| `users` | `bookings` | One-to-Many | 1 : N | `bookings.user_id` -> `users.id` (ON DELETE CASCADE) |
| `users` | `notifications` | One-to-Many | 1 : N | `notifications.user_id` -> `users.id` (ON DELETE CASCADE) |
| `routes` | `route_stops` | One-to-Many | 1 : N | `route_stops.route_id` -> `routes.id` (ON DELETE CASCADE) |
| `stops` | `route_stops` | One-to-Many | 1 : N | `route_stops.stop_id` -> `stops.id` (ON DELETE CASCADE) |
| `routes` | `schedules` | One-to-Many | 1 : N | `schedules.route_id` -> `routes.id` (ON DELETE CASCADE) |
| `buses` | `schedules` | One-to-Many | 1 : N | `schedules.bus_id` -> `buses.id` (ON DELETE CASCADE) |
| `routes` | `favorites` | One-to-Many | 1 : N | `favorites.route_id` -> `routes.id` (ON DELETE CASCADE) |
| `routes` | `bookings` | One-to-Many | 1 : N | `bookings.route_id` -> `routes.id` (ON DELETE CASCADE) |
| `buses` | `bookings` | One-to-Many | 1 : N | `bookings.bus_id` -> `buses.id` (ON DELETE CASCADE) |

---

## 4. Normalization Analysis (Up to 3NF)

The database design adheres strictly to Third Normal Form (3NF):

### First Normal Form (1NF)
1. **Atomic Values**: Every table column holds strictly single, atomic values. For example, instead of storing a comma-separated list of stops inside the `routes` table, stops are normalized into dedicated rows in `route_stops`.
2. **Unique Records**: Every entity possesses a dedicated Primary Key (`id`), ensuring all rows are uniquely identifiable.
3. **No Repeating Groups**: Repeating attributes like stops on a route or assigned buses are decoupled into relational tables.

### Second Normal Form (2NF)
1. **Meets 1NF**: The schema is verified to be in 1NF.
2. **No Partial Dependency**:
   - In junction tables (`route_stops`, `schedules`, `favorites`), every non-key attribute is dependent on the primary key (`id`).
   - In `route_stops`, attributes like `arrival_time` and `stop_order` depend upon the specific association of route and stop.
   - Stop details (`stop_name`, `location`) are not stored in `route_stops`; they reside in the independent `stops` table.

### Third Normal Form (3NF)
1. **Meets 2NF**: The schema is verified to be in 2NF.
2. **No Transitive Dependency**:
   - In `bookings`, we store `user_id`, `bus_id`, and `route_id`. Non-key attributes like user name or bus model are not duplicated in `bookings`; they are retrieved through foreign key joins to `users` and `buses`.
   - In `schedules`, route attributes (such as distance and source/destination) are maintained strictly within `routes`, preventing transitive functional dependencies ($X \to Y \land Y \to Z$).
   - In `route_stops`, geographic location of the stop is retained only in `stops`, eliminating transitive dependency between `route_id` and stop geographic details.

---

## 5. Indexing & Query Optimization Strategy

B-Tree indexes are created on high-frequency query and JOIN paths:
1. **`users(email)`**: Fast $O(\log N)$ point lookups during authentication.
2. **`routes(source, destination)`**: Speeds up user corridor searches.
3. **`buses(bus_number)`**: Rapid verification of vehicle uniqueness.
4. **`route_stops(route_id, stop_id)`**: Instant lookups during path sequence evaluation.
5. **`schedules(route_id, bus_id)`**: Accelerated multi-table JOINs in public schedule discovery.
6. **`bookings(user_id)`**: Fast retrieval of personal booking history.
