/**
 * User Controller
 */

const userService = require('../services/userService');
const { successResponse, errorResponse } = require('../utils/responseHelper');
const { isValidEmail, isValidPhone } = require('../utils/validators');

async function getUsers(req, res, next) {
  try {
    const { search } = req.query;
    const users = await userService.getAllUsers({ search });
    return successResponse(res, users, 'Users retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function getUser(req, res, next) {
  try {
    const { id } = req.params;
    const user = await userService.getUserById(id);
    return successResponse(res, user, 'User retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function updateUser(req, res, next) {
  try {
    const { id } = req.params;
    const { name, email, phone, role, password } = req.body;

    if (email && !isValidEmail(email)) {
      return errorResponse(res, 'Valid email required', 400);
    }
    if (phone && !isValidPhone(phone)) {
      return errorResponse(res, 'Valid phone required', 400);
    }

    const user = await userService.updateUser(id, { name, email, phone, role, password });
    return successResponse(res, user, 'User updated successfully');
  } catch (error) {
    next(error);
  }
}

async function deleteUser(req, res, next) {
  try {
    const { id } = req.params;
    const result = await userService.deleteUser(id);
    return successResponse(res, result, 'User deleted successfully');
  } catch (error) {
    next(error);
  }
}

async function getNotifications(req, res, next) {
  try {
    const notifications = await userService.getUserNotifications(req.user.id);
    return successResponse(res, notifications, 'Notifications retrieved');
  } catch (error) {
    next(error);
  }
}

async function markRead(req, res, next) {
  try {
    const { id } = req.params;
    const result = await userService.markNotificationAsRead(id, req.user.id);
    return successResponse(res, result, 'Notification updated');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getUsers,
  getUser,
  updateUser,
  deleteUser,
  getNotifications,
  markRead
};
