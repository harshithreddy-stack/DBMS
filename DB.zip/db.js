/**
 * Database Configuration & Connection Pool
 * Smart Public Transport Mobile App
 */

require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'smart_public_transport',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  dateStrings: true // Preserve formatted date/time strings from MySQL
});

/**
 * Test database connectivity on startup
 */
async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log(`[DB SUCCESS] Connected to MySQL database '${process.env.DB_NAME || 'smart_public_transport'}' on ${process.env.DB_HOST || 'localhost'}:${process.env.DB_PORT || '3306'}`);
    connection.release();
    return true;
  } catch (error) {
    console.warn(`[DB WARNING] Database connection failed: ${error.message}`);
    console.warn(`[DB WARNING] Make sure MySQL is running and DB_PASSWORD in backend/.env is correct.`);
    return false;
  }
}

module.exports = {
  pool,
  testConnection
};
