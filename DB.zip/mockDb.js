/**
 * Resilient In-Memory Relational Database Adapter
 * Serves as an instant zero-config fallback when MySQL root credentials
 * have not yet been configured in backend/.env, ensuring all 100 routes,
 * schedules, search queries, bookings, and logins work smoothly out of the box.
 */

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

// Load the 250 Hyderabad local routes from generateAllHyderabadRoutes
let hydRoutes = [];
let hydStops = [];
let hydBuses = [];
try {
  const hydData = require('../scripts/generateAllHyderabadRoutes');
  hydRoutes = hydData.hydRoutes || [];
  hydStops = hydData.hydStops || [];
  hydBuses = hydData.hydBuses || [];
} catch (e) {
  console.warn('Could not load generateAllHyderabadRoutes:', e.message);
}

// In-Memory Tables
const users = [
  { id: 1, name: 'System Administrator', email: 'admin@transport.com', phone: '9876543210', password: '$2a$10$sKrojjZTVbbN6NNYutgTD.PVG/Mv3v6/2pZnk/OK2Om8Refq2yjWi', role: 'admin', created_at: '2026-09-20 10:00:00' },
  { id: 2, name: 'Rahul Sharma', email: 'rahul@gmail.com', phone: '9848022338', password: '$2a$10$Og6CVU/Hr7X28OQKAj.xxOuF7mteqf2s1B6pjqbyW5f88wTvzcw/e', role: 'user', created_at: '2026-09-20 10:00:00' },
  { id: 3, name: 'Priya Reddy', email: 'priya@gmail.com', phone: '9849011223', password: '$2a$10$Og6CVU/Hr7X28OQKAj.xxOuF7mteqf2s1B6pjqbyW5f88wTvzcw/e', role: 'user', created_at: '2026-09-20 10:00:00' },
  { id: 4, name: 'Ananya Rao', email: 'ananya@gmail.com', phone: '9866033445', password: '$2a$10$Og6CVU/Hr7X28OQKAj.xxOuF7mteqf2s1B6pjqbyW5f88wTvzcw/e', role: 'user', created_at: '2026-09-20 10:00:00' }
];

const buses = hydBuses.length > 0 ? hydBuses : [
  { id: 1, bus_number: 'TS09UB1001', bus_type: 'AC Electric', capacity: 45, status: 'Active', created_at: '2026-09-20 10:00:00' },
  { id: 2, bus_number: 'TS09UB1002', bus_type: 'AC Electric', capacity: 45, status: 'Active', created_at: '2026-09-20 10:00:00' },
  { id: 3, bus_number: 'TS09Z2045', bus_type: 'Super Luxury', capacity: 40, status: 'Active', created_at: '2026-09-20 10:00:00' }
];

const stops = hydStops.length > 0 ? hydStops.map(s => ({ id: s.id, stop_name: s.name, location: s.loc })) : [
  { id: 1, stop_name: 'Patancheru Bus Station', location: 'NH 65, Industrial Area, Patancheru' },
  { id: 2, stop_name: 'Miyapur Cross Roads', location: 'Miyapur Metro Station Junction' }
];

// Build 250 Routes
const routes = hydRoutes.map((r, i) => ({
  id: i + 1,
  route_number: r.num,
  route_name: r.name,
  source: r.src,
  destination: r.dst,
  distance: r.dist,
  created_at: '2026-09-20 10:00:00'
}));

// Build Route Stops for major routes
const route_stops = [
  { id: 1, route_id: 1, stop_id: 1, stop_order: 1, arrival_time: '06:00:00', departure_time: '06:05:00', stop_name: 'Patancheru Bus Station', location: 'NH 65, Industrial Area' },
  { id: 2, route_id: 1, stop_id: 2, stop_order: 2, arrival_time: '06:20:00', departure_time: '06:23:00', stop_name: 'Miyapur Cross Roads', location: 'Miyapur Metro' },
  { id: 3, route_id: 1, stop_id: 3, stop_order: 3, arrival_time: '06:35:00', departure_time: '06:38:00', stop_name: 'Kukatpally Housing Board', location: 'KPHB Colony' },
  { id: 4, route_id: 1, stop_id: 4, stop_order: 4, arrival_time: '06:55:00', departure_time: '06:58:00', stop_name: 'Ameerpet Metro Interchange', location: 'Ameerpet' },
  { id: 5, route_id: 1, stop_id: 6, stop_order: 5, arrival_time: '07:15:00', departure_time: '07:18:00', stop_name: 'Lakdikapul', location: 'Lakdikapul Metro' },
  { id: 6, route_id: 1, stop_id: 7, stop_order: 6, arrival_time: '07:30:00', departure_time: '07:32:00', stop_name: 'Abids Post Office', location: 'Abids' },
  { id: 7, route_id: 1, stop_id: 8, stop_order: 7, arrival_time: '07:45:00', departure_time: '07:50:00', stop_name: 'Koti Bus Terminus', location: 'Central Bus Depot' },

  { id: 8, route_id: 2, stop_id: 9, stop_order: 1, arrival_time: '07:00:00', departure_time: '07:05:00', stop_name: 'Secunderabad Railway Station', location: 'Rathifile' },
  { id: 9, route_id: 2, stop_id: 5, stop_order: 2, arrival_time: '07:25:00', departure_time: '07:28:00', stop_name: 'Punjagutta X Roads', location: 'Central Mall' },
  { id: 10, route_id: 2, stop_id: 16, stop_order: 3, arrival_time: '07:50:00', departure_time: '07:53:00', stop_name: 'Madhapur Police Station', location: 'IT Corridor' },
  { id: 11, route_id: 2, stop_id: 17, stop_order: 4, arrival_time: '08:05:00', departure_time: '08:08:00', stop_name: 'Hitec City Mindspace', location: 'Cyber Towers' },
  { id: 12, route_id: 2, stop_id: 18, stop_order: 5, arrival_time: '08:20:00', departure_time: '08:25:00', stop_name: 'Kondapur RTO Office', location: 'Hafeezpet Road' },

  { id: 13, route_id: 3, stop_id: 9, stop_order: 1, arrival_time: '07:30:00', departure_time: '07:35:00', stop_name: 'Secunderabad Railway Station', location: 'Rathifile' },
  { id: 14, route_id: 3, stop_id: 10, stop_order: 2, arrival_time: '07:45:00', departure_time: '07:47:00', stop_name: 'Ranigunj Depot', location: 'MG Road' },
  { id: 15, route_id: 3, stop_id: 11, stop_order: 3, arrival_time: '07:55:00', departure_time: '07:58:00', stop_name: 'Tank Bund Ambedkar Statue', location: 'Hussain Sagar' },
  { id: 16, route_id: 3, stop_id: 6, stop_order: 4, arrival_time: '08:10:00', departure_time: '08:13:00', stop_name: 'Lakdikapul', location: 'Lakdikapul' },
  { id: 17, route_id: 3, stop_id: 12, stop_order: 5, arrival_time: '08:22:00', departure_time: '08:25:00', stop_name: 'Masab Tank', location: 'Flyover Junction' },
  { id: 18, route_id: 3, stop_id: 13, stop_order: 6, arrival_time: '08:35:00', departure_time: '08:40:00', stop_name: 'Mehdipatnam Bus Station', location: 'Rythu Bazar' }
];

// Build 200 Schedules covering all 100 routes
const schedules = [];
let schedId = 1;
routes.forEach((r, i) => {
  const routeId = r.id;
  const baseFare = Math.max(20, Math.round(15 + r.distance * 1.15));

  // Morning schedule
  const bus1 = (i % 12) + 1;
  const depHour1 = 6 + (i % 4);
  const depTime1 = `${String(depHour1).padStart(2, '0')}:${(i * 10) % 60 === 0 ? '00' : '30'}:00`;
  const arrHour1 = depHour1 + Math.max(1, Math.round(r.distance / 22));
  const arrTime1 = `${String(arrHour1).padStart(2, '0')}:${((i * 10) % 60 + 25) % 60}:00`;
  schedules.push({
    id: schedId++,
    bus_id: bus1,
    route_id: routeId,
    departure_time: depTime1,
    arrival_time: arrTime1,
    fare: baseFare,
    days: 'Daily'
  });

  // Evening schedule
  const bus2 = ((i + 3) % 12) + 1;
  const depHour2 = 14 + (i % 5);
  const depTime2 = `${String(depHour2).padStart(2, '0')}:${(i * 15) % 60 === 0 ? '15' : '45'}:00`;
  const arrHour2 = depHour2 + Math.max(1, Math.round(r.distance / 22));
  const arrTime2 = `${String(arrHour2).padStart(2, '0')}:${((i * 15) % 60 + 35) % 60}:00`;
  schedules.push({
    id: schedId++,
    bus_id: bus2,
    route_id: routeId,
    departure_time: depTime2,
    arrival_time: arrTime2,
    fare: baseFare,
    days: 'Daily'
  });
});

const favorites = [
  { id: 1, user_id: 2, route_id: 1, created_at: '2026-09-20 10:00:00' },
  { id: 2, user_id: 2, route_id: 2, created_at: '2026-09-20 10:00:00' }
];

const bookings = [
  { id: 1, user_id: 2, bus_id: 1, route_id: 1, booking_date: '2026-09-23', fare: 50.00, status: 'Confirmed', created_at: '2026-09-22 14:30:00' },
  { id: 2, user_id: 2, bus_id: 3, route_id: 2, booking_date: '2026-09-24', fare: 45.00, status: 'Confirmed', created_at: '2026-09-22 15:00:00' }
];

const notifications = [
  { id: 1, user_id: 2, message: 'Your booking for Bus TS09UB1001 is confirmed.', is_read: 1, created_at: '2026-09-22 14:30:00' },
  { id: 2, user_id: 2, message: 'Welcome to Smart Public Transport! Over 100 metropolitan routes now active.', is_read: 0, created_at: '2026-09-23 08:00:00' }
];

// Helper methods mimicking relational query behavior
function searchRoutes({ source, destination, bus_type }) {
  let matchedRoutes = routes;

  if (source && source.trim() && destination && destination.trim()) {
    const s = source.trim().toLowerCase();
    const d = destination.trim().toLowerCase();
    matchedRoutes = routes.filter(r => 
      (r.source.toLowerCase().includes(s) && r.destination.toLowerCase().includes(d)) ||
      r.route_name.toLowerCase().includes(s) || r.route_name.toLowerCase().includes(d)
    );
  } else if (source && source.trim()) {
    const s = source.trim().toLowerCase();
    matchedRoutes = routes.filter(r => r.source.toLowerCase().includes(s) || r.route_name.toLowerCase().includes(s));
  } else if (destination && destination.trim()) {
    const d = destination.trim().toLowerCase();
    matchedRoutes = routes.filter(r => r.destination.toLowerCase().includes(d) || r.route_name.toLowerCase().includes(d));
  }

  // Join with schedules and buses
  const results = [];
  for (const r of matchedRoutes) {
    const routeSchedules = schedules.filter(s => s.route_id === r.id);
    for (const sch of routeSchedules) {
      const bus = buses.find(b => b.id === sch.bus_id);
      if (!bus || bus.status === 'Out of Service') continue;
      if (bus_type && bus.bus_type !== bus_type) continue;

      const stopsForRoute = route_stops.filter(rs => rs.route_id === r.id);

      results.push({
        schedule_id: sch.id,
        departure_time: sch.departure_time,
        arrival_time: sch.arrival_time,
        fare: sch.fare,
        days: sch.days,
        route_id: r.id,
        route_number: r.route_number,
        route_name: r.route_name,
        route_source: r.source,
        route_destination: r.destination,
        distance: r.distance,
        bus_id: bus.id,
        bus_number: bus.bus_number,
        bus_type: bus.bus_type,
        capacity: bus.capacity,
        bus_status: bus.status,
        stops: stopsForRoute
      });
    }
  }

  return results;
}

module.exports = {
  users,
  buses,
  routes,
  stops,
  route_stops,
  schedules,
  favorites,
  bookings,
  notifications,
  searchRoutes
};
