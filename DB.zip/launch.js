/**
 * Universal 1-Command Node.js Project Launcher
 * Runs both backend and frontend concurrently and opens the browser.
 */

const { spawn } = require('child_process');
const path = require('path');

const rootDir = __dirname;
const backendDir = path.join(rootDir, 'smart-public-transport', 'backend');
const frontendDir = path.join(rootDir, 'smart-public-transport', 'frontend');

console.log('====================================================');
console.log('   Starting Smart Public Transport Mobile App');
console.log('====================================================');

// Spawn Backend
console.log('[1/2] Starting Backend REST API Server (Port 5000)...');
const backend = spawn('npm.cmd', ['run', 'dev'], {
  cwd: backendDir,
  stdio: 'inherit',
  shell: true
});

// Spawn Frontend
console.log('[2/2] Starting Frontend Vite App (Port 5173)...');
const frontend = spawn('npm.cmd', ['run', 'dev'], {
  cwd: frontendDir,
  stdio: 'inherit',
  shell: true
});

// Open browser after 3 seconds
setTimeout(() => {
  console.log('\n[INFO] Opening application in default web browser...');
  const openCmd = process.platform === 'win32' ? 'start' : 'open';
  spawn(openCmd, ['http://localhost:5173'], { shell: true });
}, 3000);

process.on('SIGINT', () => {
  console.log('\nStopping servers...');
  backend.kill();
  frontend.kill();
  process.exit(0);
});
