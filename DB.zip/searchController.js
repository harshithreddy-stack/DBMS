/**
 * Search Controller
 */

const searchService = require('../services/searchService');
const { successResponse } = require('../utils/responseHelper');

async function search(req, res, next) {
  try {
    const { source, destination, date, bus_type } = req.query;
    const results = await searchService.searchTransport({ source, destination, date, bus_type });
    return successResponse(res, results, `Found ${results.length} transport schedule(s) matching your criteria.`);
  } catch (error) {
    next(error);
  }
}

module.exports = {
  search
};
