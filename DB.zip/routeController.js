/**
 * Route Controller
 */

const routeService = require('../services/routeService');
const { successResponse, errorResponse } = require('../utils/responseHelper');
const { isNonEmptyString, isPositiveNumber } = require('../utils/validators');

async function getRoutes(req, res, next) {
  try {
    const { search } = req.query;
    const routes = await routeService.getAllRoutes({ search });
    return successResponse(res, routes, 'Routes retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function getRoute(req, res, next) {
  try {
    const { id } = req.params;
    const route = await routeService.getRouteById(id);
    return successResponse(res, route, 'Route details retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function createRoute(req, res, next) {
  try {
    const { route_number, route_name, source, destination, distance, stops } = req.body;

    if (!isNonEmptyString(route_number)) {
      return errorResponse(res, 'Route number is required', 400);
    }
    if (!isNonEmptyString(route_name)) {
      return errorResponse(res, 'Route name is required', 400);
    }
    if (!isNonEmptyString(source)) {
      return errorResponse(res, 'Source location is required', 400);
    }
    if (!isNonEmptyString(destination)) {
      return errorResponse(res, 'Destination location is required', 400);
    }
    if (!isPositiveNumber(distance)) {
      return errorResponse(res, 'Distance must be a positive number (km)', 400);
    }

    const route = await routeService.createRoute({ route_number, route_name, source, destination, distance, stops });
    return successResponse(res, route, 'Route created successfully', 201);
  } catch (error) {
    next(error);
  }
}

async function updateRoute(req, res, next) {
  try {
    const { id } = req.params;
    const { route_number, route_name, source, destination, distance, stops } = req.body;

    if (distance !== undefined && !isPositiveNumber(distance)) {
      return errorResponse(res, 'Distance must be a positive number', 400);
    }

    const route = await routeService.updateRoute(id, { route_number, route_name, source, destination, distance, stops });
    return successResponse(res, route, 'Route updated successfully');
  } catch (error) {
    next(error);
  }
}

async function deleteRoute(req, res, next) {
  try {
    const { id } = req.params;
    const result = await routeService.deleteRoute(id);
    return successResponse(res, result, 'Route deleted successfully');
  } catch (error) {
    next(error);
  }
}

async function addStop(req, res, next) {
  try {
    const { id } = req.params;
    const { stop_id, stop_order, arrival_time, departure_time } = req.body;

    if (!stop_id || !stop_order) {
      return errorResponse(res, 'stop_id and stop_order are required', 400);
    }

    const route = await routeService.addStopToRoute(id, { stop_id, stop_order, arrival_time, departure_time });
    return successResponse(res, route, 'Stop attached to route successfully');
  } catch (error) {
    next(error);
  }
}

async function removeStop(req, res, next) {
  try {
    const { id, stopId } = req.params;
    const route = await routeService.removeStopFromRoute(id, stopId);
    return successResponse(res, route, 'Stop removed from route successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getRoutes,
  getRoute,
  createRoute,
  updateRoute,
  deleteRoute,
  addStop,
  removeStop
};
