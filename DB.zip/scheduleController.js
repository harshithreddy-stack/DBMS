/**
 * Schedule Controller
 */

const scheduleService = require('../services/scheduleService');
const { successResponse, errorResponse } = require('../utils/responseHelper');
const { isPositiveNumber } = require('../utils/validators');

async function getSchedules(req, res, next) {
  try {
    const { route_id, bus_id, days } = req.query;
    const schedules = await scheduleService.getAllSchedules({ route_id, bus_id, days });
    return successResponse(res, schedules, 'Schedules retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function getSchedule(req, res, next) {
  try {
    const { id } = req.params;
    const schedule = await scheduleService.getScheduleById(id);
    return successResponse(res, schedule, 'Schedule retrieved successfully');
  } catch (error) {
    next(error);
  }
}

async function createSchedule(req, res, next) {
  try {
    const { bus_id, route_id, departure_time, arrival_time, fare, days } = req.body;

    if (!bus_id || !route_id) {
      return errorResponse(res, 'bus_id and route_id are required', 400);
    }
    if (!departure_time || !arrival_time) {
      return errorResponse(res, 'departure_time and arrival_time are required (HH:MM:SS)', 400);
    }
    if (!isPositiveNumber(fare)) {
      return errorResponse(res, 'fare must be a positive number', 400);
    }

    const schedule = await scheduleService.createSchedule({ bus_id, route_id, departure_time, arrival_time, fare, days });
    return successResponse(res, schedule, 'Schedule created successfully', 201);
  } catch (error) {
    next(error);
  }
}

async function updateSchedule(req, res, next) {
  try {
    const { id } = req.params;
    const { bus_id, route_id, departure_time, arrival_time, fare, days } = req.body;

    if (fare !== undefined && !isPositiveNumber(fare)) {
      return errorResponse(res, 'fare must be a positive number', 400);
    }

    const schedule = await scheduleService.updateSchedule(id, { bus_id, route_id, departure_time, arrival_time, fare, days });
    return successResponse(res, schedule, 'Schedule updated successfully');
  } catch (error) {
    next(error);
  }
}

async function deleteSchedule(req, res, next) {
  try {
    const { id } = req.params;
    const result = await scheduleService.deleteSchedule(id);
    return successResponse(res, result, 'Schedule deleted successfully');
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getSchedules,
  getSchedule,
  createSchedule,
  updateSchedule,
  deleteSchedule
};
